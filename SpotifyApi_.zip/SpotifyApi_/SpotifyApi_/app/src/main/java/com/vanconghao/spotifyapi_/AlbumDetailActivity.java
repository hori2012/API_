package com.vanconghao.spotifyapi_;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.squareup.picasso.Picasso;
import com.vanconghao.adapter.TrackAdapter;
import com.vanconghao.api.ApiService;
import com.vanconghao.model.Album;
import com.vanconghao.model.Token;
import com.vanconghao.model.Track;
import com.vanconghao.spotifyapi_.databinding.ActivityAlbumDetailBinding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AlbumDetailActivity extends AppCompatActivity {
    private ActivityAlbumDetailBinding binding;
    private TrackAdapter trackAdapter;
    private String Token = "BQCGrYfzYyweGIqhodk5mNqvw9o--Ws5tnlm5PDjPUMo1dMpxilrN0t8D1LDV1gtl6Hhlue8iRXeXcsFTjDE9Spe5izJaGExuhsJ6F3K-v3RVnbJzrdd";
    private ArrayList<Track> trackArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAlbumDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        generateToken();
    }

    private void addEvent() {
        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("bundle");
        Album album = (Album) bundle.getSerializable("album");
        Picasso.get().load(album.getImages()).into(binding.imvAlbum);
        binding.txtNameAlbum.setText(album.getName());
        binding.txtArtistAlbum.setText(album.getNameArtist());
        binding.txtReleaseDateAlbum.setText(album.getRelease_date());
        binding.txtTotalTrack.setText(String.valueOf(album.getTotal_tracks()));
        initTrack(album.getId());
        binding.lvDetailAlbum.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intentUrl = new Intent(Intent.ACTION_VIEW, Uri.parse(trackArrayList.get(i).getExternal_urls()));
                startActivity(intentUrl);
            }
        });
        binding.imvPlayAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://open.spotify.com/album/" + album.getId());
                Intent intentUrl = new Intent(Intent.ACTION_VIEW,uri);
                startActivity(intentUrl);
            }
        });
    }

    private void initTrack(String id) {
        trackArrayList = new ArrayList<>();
        ApiService.apiService.getAlbum(id, "Bearer " + Token).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject jsonObject = response.body();
                if(jsonObject != null){
                    JsonArray jsonArray = jsonObject.get("tracks").getAsJsonObject().get("items").getAsJsonArray();
                    String nameArtist = binding.txtArtistAlbum.getText().toString();
                    String images = jsonObject.get("images").getAsJsonArray().get(0).getAsJsonObject().get("url").getAsString();
                    for(int i = 0; i <jsonArray.size(); i++){
                        JsonObject object = jsonArray.get(i).getAsJsonObject();
                       String external_urls = object.get("external_urls").getAsJsonObject().get("spotify").getAsString();
                       String id = object.get("id").getAsString();
                       String name = object.get("name").getAsString();
                       trackArrayList.add(new Track(nameArtist, images, external_urls, id, name));
                    }
                    initAdapter();
                }else{
                    Toast.makeText(AlbumDetailActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(AlbumDetailActivity.this, "Connect api fail !!", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void initAdapter() {
        trackAdapter = new TrackAdapter(AlbumDetailActivity.this, R.layout.track_layout, trackArrayList);
        binding.lvDetailAlbum.setAdapter(trackAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        //generateToken();
    }
    private void generateToken(){
       com.vanconghao.model.Token authorization = new Token();
        ApiService.apiToken.getToken("client_credentials",authorization.getAuthorization(), "application/x-www-form-urlencoded").enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject jsonObject = response.body();
                if(jsonObject != null){
                    Token = jsonObject.get("access_token").getAsString();
                }else{
                    Toast.makeText(AlbumDetailActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                }
                addEvent();
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(AlbumDetailActivity.this, "Connect api fail", Toast.LENGTH_LONG).show();
            }
        });
    }
}