package com.vanconghao.api;

import com.google.gson.JsonObject;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.HeaderMap;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    ApiService apiService = new Retrofit.Builder()
            .baseUrl("https://api.spotify.com/v1/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService.class);
    ApiService apiToken = new Retrofit.Builder()
            .baseUrl("https://accounts.spotify.com/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService.class);

    @GET("albums/{id}")
    Call<JsonObject> getAlbum(@Path("id") String id,
                              @Header("Authorization") String Authorization);
    @GET("playlists/{playlist_id}")
    Call<JsonObject> getList(@Path("playlist_id") String playlist_id,
                             @Header("Authorization") String Authorization);
    @GET("search")
    Call<JsonObject> getSearch(@Query("q") String q,
                               @Query("type") String type,
                               @Header("Authorization") String Authorization);
//    @Headers({
//            "Authorization: Basic ZTk1NWZjMGEyZWNiNGZhY2E1ZmVhOWY4MzYyNjk5OWY6NmZmMjA3ZDBmMzY4NDdkN2FiOTU4M2ZjYzljY2M2ZGM=",
//            "Content-Type: application/x-www-form-urlencoded"
//    })
    @POST("token")
    Call<JsonObject> getToken(@Query("grant_type") String grant_type,
                              @Header("Authorization") String authorization,
                              @Header("Content-Type") String content_type);
}
