package com.vanconghao.model;

import java.util.Base64;

public class Token {
   private String CLIENT_ID ="e955fc0a2ecb4faca5fea9f83626999f";
   private String CLIENT_SECRET ="6ff207d0f36847d7ab9583fcc9ccc6dc";

    public Token(String CLIENT_ID, String CLIENT_SECRET) {
        this.CLIENT_ID = CLIENT_ID;
        this.CLIENT_SECRET = CLIENT_SECRET;
    }
    public Token() {
    }
    public String getAuthorization(){
        String encodeBytes = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            encodeBytes = Base64.getEncoder().encodeToString((this.CLIENT_ID + ":" + this.CLIENT_SECRET).getBytes());
        }
        return encodeBytes;
    }
}
