package com.vanconghao.model;

import java.io.Serializable;

public class Album implements Serializable {
    private String nameArtist;
    private String id;
    private String images;
    private String name;
    private String release_date;
    private int total_tracks;

    public Album(String nameArtist, String id, String images, String name, String release_date, int total_tracks) {
        this.nameArtist = nameArtist;
        this.id = id;
        this.images = images;
        this.name = name;
        this.release_date = release_date;
        this.total_tracks = total_tracks;
    }

    public String getNameArtist() {
        return nameArtist;
    }

    public void setNameArtist(String nameArtist) {
        this.nameArtist = nameArtist;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public int getTotal_tracks() {
        return total_tracks;
    }

    public void setTotal_tracks(int total_tracks) {
        this.total_tracks = total_tracks;
    }
}
