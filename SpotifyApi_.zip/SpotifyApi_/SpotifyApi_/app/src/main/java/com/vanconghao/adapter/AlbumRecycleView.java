package com.vanconghao.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;
import com.vanconghao.model.Album;
import com.vanconghao.spotifyapi_.AlbumDetailActivity;
import com.vanconghao.spotifyapi_.R;

import java.util.ArrayList;

public class AlbumRecycleView extends RecyclerView.Adapter<AlbumRecycleView.ViewHolder> {
    private Context context;
    private ArrayList<Album> albumArrayList;

    public AlbumRecycleView(Context context, ArrayList<Album> albumArrayList) {
        this.context = context;
        this.albumArrayList = albumArrayList;
    }

    @NonNull
    @Override
    public AlbumRecycleView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.album_layout, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AlbumRecycleView.ViewHolder holder, int position) {
        Album album = albumArrayList.get(position);
        Picasso.get().load(album.getImages()).into(holder.imvThumb);
        holder.txtNameAlbum.setText(album.getName());
        holder.txtArtistAlbum.setText(album.getNameArtist());
        holder.txtReleaseDate.setText(album.getRelease_date());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, AlbumDetailActivity.class);
                Bundle bundle = new Bundle();
                intent.putExtra("bundle", bundle);
                bundle.putSerializable("album",album);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return albumArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imvThumb;
        TextView txtNameAlbum, txtArtistAlbum, txtReleaseDate;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imvThumb = itemView.findViewById(R.id.imvThumb);
            txtNameAlbum = itemView.findViewById(R.id.txtNameAlbum);
            txtArtistAlbum = itemView.findViewById(R.id.txtArtistAlbum);
            txtReleaseDate = itemView.findViewById(R.id.txtReleaseDateAlbum);
        }
    }
}
