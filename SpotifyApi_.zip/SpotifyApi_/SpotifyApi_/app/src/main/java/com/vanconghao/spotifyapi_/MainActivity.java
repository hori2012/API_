package com.vanconghao.spotifyapi_;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.vanconghao.adapter.AlbumAdapter;
import com.vanconghao.adapter.AlbumRecycleView;
import com.vanconghao.api.ApiService;
import com.vanconghao.model.Album;
import com.vanconghao.model.Token;
import com.vanconghao.spotifyapi_.databinding.ActivityMainBinding;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private String id = "37i9dQZF1DX5UMwGFV95IS";
    private String idTrend = "37i9dQZF1DX29nkpzsmQhh";
    private String idPopular = "37i9dQZEVXbKZyn1mKjmIl";
    private String Token = "BQCGrYfzYyweGIqhodk5mNqvw9o--Ws5tnlm5PDjPUMo1dMpxilrN0t8D1LDV1gtl6Hhlue8iRXeXcsFTjDE9Spe5izJaGExuhsJ6F3K-v3RVnbJzrdd";
    private AlbumAdapter albumAdapter;
    private ArrayList<Album> albumArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
//        initAlbum();
       generateToken();
    }

    private void initAlbumPopularRecycleView() {
        ArrayList<Album> arrayList = new ArrayList<>();
        binding.rcvAlbumPopular.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        binding.rcvAlbumPopular.setLayoutManager(layoutManager);
        ApiService.apiService.getList(idPopular, "Bearer " + Token).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject jsonObject = response.body();
                if(jsonObject != null){
                    JsonArray jsonArray = jsonObject.get("tracks").getAsJsonObject().get("items").getAsJsonArray();
                    for(int i = 0; i < jsonArray.size(); i++){
                        JsonObject object = jsonArray.get(i).getAsJsonObject();
                        String nameArtist = "";
                        for(int j = 0; j < object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().size(); j++){
                            nameArtist += object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().get(j).getAsJsonObject().get("name").getAsString();
                            if(j != object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().size() - 1){
                                nameArtist += " - ";
                            }
                        }
                        String id = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("id").getAsString();
                        String images = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("images").getAsJsonArray().get(0).getAsJsonObject().get("url").getAsString();
                        String name = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("name").getAsString();
                        String release_date = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("release_date").getAsString();
                        int total_tracks = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("total_tracks").getAsInt();
                        arrayList.add(new Album(nameArtist, id, images, name, release_date, total_tracks));
                    }
                }else{
                    Toast.makeText(MainActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                }
                AlbumRecycleView albumRecycleView = new AlbumRecycleView(MainActivity.this,arrayList);
                binding.rcvAlbumPopular.setAdapter(albumRecycleView);
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Connect api fail !!", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void initAlbumTrendingRecycleView() {
        ArrayList<Album> arrayList = new ArrayList<>();
        binding.rcvAlbumTrending.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        binding.rcvAlbumTrending.setLayoutManager(layoutManager);
        ApiService.apiService.getList(idTrend, "Bearer " + Token).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject jsonObject = response.body();
                if(jsonObject != null){
                    JsonArray jsonArray = jsonObject.get("tracks").getAsJsonObject().get("items").getAsJsonArray();
                    for(int i = 0; i < jsonArray.size(); i++){
                        JsonObject object = jsonArray.get(i).getAsJsonObject();
                        String nameArtist = "";
                        for(int j = 0; j < object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().size(); j++){
                            nameArtist += object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().get(j).getAsJsonObject().get("name").getAsString();
                            if(j != object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().size() - 1){
                                nameArtist += " - ";
                            }
                        }
                        String id = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("id").getAsString();
                        String images = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("images").getAsJsonArray().get(0).getAsJsonObject().get("url").getAsString();
                        String name = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("name").getAsString();
                        String release_date = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("release_date").getAsString();
                        int total_tracks = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("total_tracks").getAsInt();
                        arrayList.add(new Album(nameArtist, id, images, name, release_date, total_tracks));
                    }
                }else{
                    Toast.makeText(MainActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                }
                AlbumRecycleView albumRecycleView = new AlbumRecycleView(MainActivity.this,arrayList);
                binding.rcvAlbumTrending.setAdapter(albumRecycleView);
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Connect api fail !!", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void initAlbumRecycleView() {
        ArrayList<Album> arrayList = new ArrayList<>();
        binding.rcvAlbum.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        binding.rcvAlbum.setLayoutManager(layoutManager);
        ApiService.apiService.getList(id, "Bearer " + Token).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject jsonObject = response.body();
                if(jsonObject != null){
                    JsonArray jsonArray = jsonObject.get("tracks").getAsJsonObject().get("items").getAsJsonArray();
                    for(int i = 0; i < jsonArray.size(); i++){
                        JsonObject object = jsonArray.get(i).getAsJsonObject();
                        String nameArtist = "";
                        for(int j = 0; j < object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().size(); j++){
                            nameArtist += object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().get(j).getAsJsonObject().get("name").getAsString();
                            if(j != object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().size() - 1){
                                nameArtist += " - ";
                            }
                        }
                        String id = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("id").getAsString();
                        String images = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("images").getAsJsonArray().get(0).getAsJsonObject().get("url").getAsString();
                        String name = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("name").getAsString();
                        String release_date = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("release_date").getAsString();
                        int total_tracks = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("total_tracks").getAsInt();
                        arrayList.add(new Album(nameArtist, id, images, name, release_date, total_tracks));
                    }
                }else{
                    Toast.makeText(MainActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                }
                AlbumRecycleView albumRecycleView = new AlbumRecycleView(MainActivity.this,arrayList);
                binding.rcvAlbum.setAdapter(albumRecycleView);
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Connect api fail !!", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void addEvent() {
        //Click album direct activity Album detail
        //write code here...
        binding.edtSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if(i == EditorInfo.IME_ACTION_DONE || (keyEvent.getAction() == KeyEvent.ACTION_DOWN && keyEvent.getKeyCode() == KeyEvent.KEYCODE_ENTER)){
                    Intent intent = new Intent(MainActivity.this, SearchActivity.class);
                    intent.putExtra("search_query", binding.edtSearch.getText().toString());
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });
    }

    private void initAlbum() {
        albumArrayList = new ArrayList<>();
        ApiService.apiService.getList(id, "Bearer " + Token).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject jsonObject = response.body();
                if(jsonObject != null){
                    JsonArray jsonArray = jsonObject.get("tracks").getAsJsonObject().get("items").getAsJsonArray();
                    for(int i = 0; i < jsonArray.size(); i++){
                        JsonObject object = jsonArray.get(i).getAsJsonObject();
                        String nameArtist = "";
                        for(int j = 0; j < object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().size(); j++){
                            nameArtist += object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().get(j).getAsJsonObject().get("name").getAsString();
                            if(j != object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("artists").getAsJsonArray().size() - 1){
                                nameArtist += " - ";
                            }
                        }
                        String id = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("id").getAsString();
                        String images = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("images").getAsJsonArray().get(0).getAsJsonObject().get("url").getAsString();
                        String name = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("name").getAsString();
                        String release_date = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("release_date").getAsString();
                        int total_tracks = object.get("track").getAsJsonObject().get("album").getAsJsonObject().get("total_tracks").getAsInt();
                        albumArrayList.add(new Album(nameArtist, id, images, name, release_date, total_tracks));
                    }
                    initAdapter();
                }else{
                    Toast.makeText(MainActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Connect api fail !!", Toast.LENGTH_LONG).show();
            }
        });
    }
    private void initAdapter(){
        albumAdapter = new AlbumAdapter(MainActivity.this, R.layout.album_layout, albumArrayList);
//     binding.lvAlbum.setAdapter(albumAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
       // generateToken();
    }
    private void generateToken(){
        Token authorization = new Token();
        ApiService.apiToken.getToken("client_credentials",authorization.getAuthorization(), "application/x-www-form-urlencoded").enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject jsonObject = response.body();
                if(jsonObject != null){
                    Token = jsonObject.get("access_token").getAsString();

                }else{
                    Toast.makeText(MainActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                }
                initAlbumRecycleView();
                initAlbumTrendingRecycleView();
                initAlbumPopularRecycleView();
                addEvent();
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Connect api fail", Toast.LENGTH_LONG).show();
            }
        });
    }
}