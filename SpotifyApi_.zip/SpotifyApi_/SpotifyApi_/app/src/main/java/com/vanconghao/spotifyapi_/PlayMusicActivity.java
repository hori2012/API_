package com.vanconghao.spotifyapi_;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Toast;

import com.vanconghao.model.Track;
import com.vanconghao.spotifyapi_.databinding.ActivityPlayMusicBinding;

import java.io.IOException;

public class PlayMusicActivity extends AppCompatActivity {
    private ActivityPlayMusicBinding binding;
    private MediaPlayer mediaPlayer;
    private Handler handler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPlayMusicBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        mediaPlayer = new MediaPlayer();
        binding.seekbarPlay.setMax(100);
        binding.imvPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mediaPlayer.isPlaying()){
                    handler.removeCallbacks(runnable);
                    mediaPlayer.pause();
                    binding.imvPlayPause.setImageResource(R.drawable.ic_play);
                }else{
                    mediaPlayer.start();
                    binding.imvPlayPause.setImageResource(R.drawable.ic_pause);
                    updateSeerBar();
                }
            }
        });
        urlMediaPlay();
        binding.seekbarPlay.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                SeekBar seekBar = (SeekBar) view;
                int position = (mediaPlayer.getDuration() / 100) * seekBar.getProgress();
                 mediaPlayer.seekTo(position);
                 binding.txtCurrentTime.setText(milesSecondToTimer(mediaPlayer.getCurrentPosition()));
                return false;
            }
        });
        mediaPlayer.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {
            @Override
            public void onBufferingUpdate(MediaPlayer mediaPlayer, int i) {
                binding.seekbarPlay.setSecondaryProgress(i);
            }
        });
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                binding.seekbarPlay.setProgress(0);
                binding.imvPlayPause.setImageResource(R.drawable.ic_play);
                binding.txtCurrentTime.setText(R.string._0_00);
                binding.txtTotalDuration.setText(R.string._0_00);
                mediaPlayer.reset();
                urlMediaPlay();
            }
        });
    }

    private void urlMediaPlay(){
        try {
            Intent intent = getIntent();
            Bundle bundle = intent.getBundleExtra("trackBundle");
            Track track = (Track) bundle.getSerializable("track_inf");
            mediaPlayer.setDataSource(track.getExternal_urls());
            mediaPlayer.prepare();
            binding.txtTotalDuration.setText(milesSecondToTimer(mediaPlayer.getDuration()));
        }
        catch (IOException e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            updateSeerBar();
            long currentDuration = mediaPlayer.getCurrentPosition();
            binding.txtCurrentTime.setText(milesSecondToTimer(currentDuration));
        }
    };

    private void updateSeerBar(){
        if(mediaPlayer.isPlaying()){
            binding.seekbarPlay.setProgress((int)(((float)mediaPlayer.getCurrentPosition() / mediaPlayer.getDuration()) * 100));
            handler.postDelayed(runnable,1000);
        }
    }
    private String milesSecondToTimer(long milesSecond){
        String timer = "";
        String secondString = "";
        int hours = (int) (milesSecond / (1000 * 60 * 60));
        int minutes = (int) (milesSecond % (1000 * 60 * 60) / (1000 * 60));
        int seconds = (int) ((milesSecond % (1000 * 60 * 60)) % (1000 * 60) / 1000);
        if(hours > 0){
            timer = hours + ":";
        }
        if(seconds < 10){
            secondString = "0" + seconds;
        }
        else{
            secondString += seconds;
        }
        timer += minutes + ":" + secondString;
        return timer;
    }
}