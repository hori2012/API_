package com.vanconghao.spotifyapi_;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.vanconghao.adapter.TrackAdapter;
import com.vanconghao.api.ApiService;
import com.vanconghao.model.Token;
import com.vanconghao.model.Track;
import com.vanconghao.spotifyapi_.databinding.ActivitySearchBinding;

import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchActivity extends AppCompatActivity {
    private ActivitySearchBinding binding;
    private TrackAdapter trackAdapter;
    private String Token = "Not Token";

    private ArrayList<Track> trackArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        generateToken();
    }

    private void addEvent() {
        binding.edtSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if(i == EditorInfo.IME_ACTION_DONE || (keyEvent.getAction() == KeyEvent.ACTION_DOWN && keyEvent.getKeyCode() == KeyEvent.KEYCODE_ENTER)){
                   trackArrayList = new ArrayList<>();
                    ApiService.apiService.getSearch(binding.edtSearch.getText().toString(), "track", "Bearer " + Token).enqueue(new Callback<JsonObject>() {
                        @Override
                        public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                            JsonObject jsonObject = response.body();
                            if(jsonObject != null){
                                JsonArray jsonArray = jsonObject.get("tracks").getAsJsonObject().get("items").getAsJsonArray();
                                for(int i = 0; i < jsonArray.size(); i++){
                                    JsonObject object = jsonArray.get(i).getAsJsonObject();
                                    String nameArtist ="";
                                    for(int j = 0; j < object.get("artists").getAsJsonArray().size(); j++){
                                        nameArtist += object.get("artists").getAsJsonArray().get(j).getAsJsonObject().get("name").getAsString() + " - ";
                                    }
                                    String images = object.get("album").getAsJsonObject().get("images").getAsJsonArray().get(0).getAsJsonObject().get("url").getAsString();
                                    String external_urls = object.get("external_urls").getAsJsonObject().get("spotify").getAsString();
                                    String id = object.get("id").getAsString();
                                    String name = object.get("name").getAsString();
                                    trackArrayList.add(new Track(nameArtist, images, external_urls, id, name));
                                }
                                initAdapter();
                            }else{
                                Toast.makeText(SearchActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                            }
                        }
                        @Override
                        public void onFailure(Call<JsonObject> call, Throwable t) {
                            Toast.makeText(SearchActivity.this, "Connect api fail !!", Toast.LENGTH_LONG).show();
                        }
                    });
                    return true;
                }
                return false;
            }
        });
        binding.lvTrack.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intentUrl = new Intent(Intent.ACTION_VIEW, Uri.parse(trackArrayList.get(i).getExternal_urls()));
                startActivity(intentUrl);
            }
        });
    }

    private void initTrack() {
        Intent intent = getIntent();
        String search_query = intent.getStringExtra("search_query");
        trackArrayList = new ArrayList<>();
        ApiService.apiService.getSearch(search_query, "track", "Bearer " + Token).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject jsonObject = response.body();
                if(jsonObject != null){
                    JsonArray jsonArray = jsonObject.get("tracks").getAsJsonObject().get("items").getAsJsonArray();
                    for(int i = 0; i < jsonArray.size(); i++){
                        JsonObject object = jsonArray.get(i).getAsJsonObject();
                        String nameArtist ="";
                        for(int j = 0; j < object.get("artists").getAsJsonArray().size(); j++){
                            nameArtist += object.get("artists").getAsJsonArray().get(j).getAsJsonObject().get("name").getAsString();
                            if(j != object.get("artists").getAsJsonArray().size() - 1){
                                nameArtist += " - ";
                            }
                        }
                        String images = object.get("album").getAsJsonObject().get("images").getAsJsonArray().get(0).getAsJsonObject().get("url").getAsString();
                        String external_urls = object.get("external_urls").getAsJsonObject().get("spotify").getAsString();
                        String id = object.get("id").getAsString();
                        String name = object.get("name").getAsString();
                        trackArrayList.add(new Track(nameArtist, images, external_urls, id, name));
                    }
                    initAdapter();
                }else{
                    Toast.makeText(SearchActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(SearchActivity.this, "Connect api fail !!", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void initAdapter(){
        trackAdapter = new TrackAdapter(SearchActivity.this, R.layout.track_layout, trackArrayList);
        binding.lvTrack.setAdapter(trackAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        //generateToken();
    }

    private void generateToken(){
       com.vanconghao.model.Token authorization = new Token();
        ApiService.apiToken.getToken("client_credentials",authorization.getAuthorization(), "application/x-www-form-urlencoded").enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                JsonObject jsonObject = response.body();
                if(jsonObject != null){
                    Token = jsonObject.get("access_token").getAsString();
                }else{
                    Toast.makeText(SearchActivity.this, "Data is null !!", Toast.LENGTH_LONG).show();
                }
                initTrack();
                addEvent();
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(SearchActivity.this, "Connect api fail", Toast.LENGTH_LONG).show();
            }
        });
    }
}