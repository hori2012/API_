package com.vanconghao.model;

import java.io.Serializable;

public class Track implements Serializable {
    private String nameArtist;
    private String images;
    private String external_urls;
    private String id;
    private String name;

    public Track(String nameArtist, String images, String external_urls, String id, String name) {
        this.nameArtist = nameArtist;
        this.images = images;
        this.external_urls = external_urls;
        this.id = id;
        this.name = name;
    }

    public String getNameArtist() {
        return nameArtist;
    }

    public void setNameArtist(String nameArtist) {
        this.nameArtist = nameArtist;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getExternal_urls() {
        return external_urls;
    }

    public void setExternal_urls(String external_urls) {
        this.external_urls = external_urls;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
