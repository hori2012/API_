package com.vanconghao.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.vanconghao.model.Album;
import com.vanconghao.model.Track;
import com.vanconghao.spotifyapi_.R;

import java.util.ArrayList;

public class TrackAdapter extends BaseAdapter {
    private Activity context;
    private int item_layout;
    private ArrayList<Track> trackArrayList;

    public TrackAdapter(Activity context, int item_layout, ArrayList<Track> trackArrayList) {
        this.context = context;
        this.item_layout = item_layout;
        this.trackArrayList = trackArrayList;
    }

    @Override
    public int getCount() {
        return trackArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return trackArrayList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        AlbumAdapter.ViewHolder holder;
        if(view == null){
            holder = new AlbumAdapter.ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view =inflater.inflate(item_layout, null);
            holder.imvThumb = view.findViewById(R.id.imvThumb);
            holder.txtName = view.findViewById(R.id.txtNameTrack);
            holder.txtArtist = view.findViewById(R.id.txtArtistTrack);

            view.setTag(holder);
        }else{
            holder = (AlbumAdapter.ViewHolder) view.getTag();
        }
        Track track = trackArrayList.get(i);
        Picasso.get().load(track.getImages()).into(holder.imvThumb);
        holder.txtName.setText(track.getName());
        holder.txtArtist.setText(track.getNameArtist());
        return view;
    }
    public static class ViewHolder{
        ImageView imvThumb;
        TextView txtName, txtArtist;
    }
}
