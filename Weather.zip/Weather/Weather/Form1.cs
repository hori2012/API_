﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Weather
{
    public partial class Form1 : Form
    {
        const string appid = "7da64dc8c44c50bdfb01fcec02e507b1";
        string idCity = "1566083";
        public Form1()
        {
            InitializeComponent();
            getWeather(idCity);s
            //getForcast(idCity);
        }

        //private void getForcast(string id)
        //{
        //    int day = 6;
        //    string url = string.Format("http://api.openweathermap.org/data/2.5/forecast/daily?id={0}&cnt={1}&appid={2}", id, day, appid);
        //    using (WebClient webClient = new WebClient())
        //    {
        //        var js = webClient.DownloadString(url);
        //        var Object = JsonConvert.DeserializeObject<WeatherForcast>(js);
        //        WeatherForcast weatherForcast = Object;

        //        lbConditions.Text = string.Format("{0}", weatherForcast.list[1].weather[0].main);
        //        lbDescription.Text = string.Format("{0}", weatherForcast.list[1].weather[0].descriptions);
        //        lbDes2.Text = string.Format("{0} °C", weatherForcast.list[1].temp);
        //        lbSpeed.Text = string.Format("{0}", weatherForcast.list[1].speed);
        //        lbSpeed.Text = string.Format("{0}", weatherForcast.list[1].speed);

        //    }
        //}

        private void getWeather(string id)
        {
            using(WebClient webClient = new WebClient())
            {
                string url = string.Format("http://api.openweathermap.org/data/2.5/weather?id={0}&appid={1}&units=metric&cnt=6", id, appid);
                var json = webClient.DownloadString(url);
                var result = JsonConvert.DeserializeObject<WeatherInfo.root>(json);
                WeatherInfo.root output = result;
                lbtxtCity.Text = string.Format("{0}", output.name);
                lbtxtCountry.Text = string.Format("{0}", output.sys.country);
                lbtxtDoCe.Text = string.Format("{0} \u00b0C", output.main.temp);
            }
        }
    }
}
