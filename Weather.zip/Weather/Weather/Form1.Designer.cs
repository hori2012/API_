﻿namespace Weather
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbtxtCity = new System.Windows.Forms.Label();
            this.lbtxtDoCe = new System.Windows.Forms.Label();
            this.lbtxtCountry = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbDay = new System.Windows.Forms.Label();
            this.lbConditions = new System.Windows.Forms.Label();
            this.lbDescription = new System.Windows.Forms.Label();
            this.lbSpeed = new System.Windows.Forms.Label();
            this.lbDes2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbtxtCity
            // 
            this.lbtxtCity.AutoSize = true;
            this.lbtxtCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtxtCity.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbtxtCity.Location = new System.Drawing.Point(12, 9);
            this.lbtxtCity.Name = "lbtxtCity";
            this.lbtxtCity.Size = new System.Drawing.Size(312, 67);
            this.lbtxtCity.TabIndex = 0;
            this.lbtxtCity.Text = "Thành phố";
            // 
            // lbtxtDoCe
            // 
            this.lbtxtDoCe.AutoSize = true;
            this.lbtxtDoCe.Font = new System.Drawing.Font("Microsoft Sans Serif", 45F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtxtDoCe.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbtxtDoCe.Location = new System.Drawing.Point(12, 216);
            this.lbtxtDoCe.Name = "lbtxtDoCe";
            this.lbtxtDoCe.Size = new System.Drawing.Size(91, 85);
            this.lbtxtDoCe.TabIndex = 1;
            this.lbtxtDoCe.Text = "C";
            // 
            // lbtxtCountry
            // 
            this.lbtxtCountry.AutoSize = true;
            this.lbtxtCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtxtCountry.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbtxtCountry.Location = new System.Drawing.Point(12, 106);
            this.lbtxtCountry.Name = "lbtxtCountry";
            this.lbtxtCountry.Size = new System.Drawing.Size(266, 67);
            this.lbtxtCountry.TabIndex = 2;
            this.lbtxtCountry.Text = "Quốc gia";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(439, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(227, 67);
            this.label1.TabIndex = 3;
            this.label1.Text = "Forcast";
            // 
            // lbDay
            // 
            this.lbDay.AutoSize = true;
            this.lbDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDay.ForeColor = System.Drawing.Color.Yellow;
            this.lbDay.Location = new System.Drawing.Point(443, 76);
            this.lbDay.Name = "lbDay";
            this.lbDay.Size = new System.Drawing.Size(111, 46);
            this.lbDay.TabIndex = 4;
            this.lbDay.Text = "Days";
            // 
            // lbConditions
            // 
            this.lbConditions.AutoSize = true;
            this.lbConditions.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbConditions.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lbConditions.Location = new System.Drawing.Point(443, 127);
            this.lbConditions.Name = "lbConditions";
            this.lbConditions.Size = new System.Drawing.Size(210, 46);
            this.lbConditions.TabIndex = 5;
            this.lbConditions.Text = "Conditions";
            // 
            // lbDescription
            // 
            this.lbDescription.AutoSize = true;
            this.lbDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbDescription.Location = new System.Drawing.Point(443, 187);
            this.lbDescription.Name = "lbDescription";
            this.lbDescription.Size = new System.Drawing.Size(221, 46);
            this.lbDescription.TabIndex = 6;
            this.lbDescription.Text = "Description";
            // 
            // lbSpeed
            // 
            this.lbSpeed.AutoSize = true;
            this.lbSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSpeed.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lbSpeed.Location = new System.Drawing.Point(706, 76);
            this.lbSpeed.Name = "lbSpeed";
            this.lbSpeed.Size = new System.Drawing.Size(167, 46);
            this.lbSpeed.TabIndex = 7;
            this.lbSpeed.Text = "12 Km/h";
            // 
            // lbDes2
            // 
            this.lbDes2.AutoSize = true;
            this.lbDes2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDes2.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.lbDes2.Location = new System.Drawing.Point(706, 187);
            this.lbDes2.Name = "lbDes2";
            this.lbDes2.Size = new System.Drawing.Size(64, 46);
            this.lbDes2.TabIndex = 8;
            this.lbDes2.Text = "26";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 464);
            this.Controls.Add(this.lbDes2);
            this.Controls.Add(this.lbSpeed);
            this.Controls.Add(this.lbDescription);
            this.Controls.Add(this.lbConditions);
            this.Controls.Add(this.lbDay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbtxtCountry);
            this.Controls.Add(this.lbtxtDoCe);
            this.Controls.Add(this.lbtxtCity);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbtxtCity;
        private System.Windows.Forms.Label lbtxtDoCe;
        private System.Windows.Forms.Label lbtxtCountry;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbDay;
        private System.Windows.Forms.Label lbConditions;
        private System.Windows.Forms.Label lbDescription;
        private System.Windows.Forms.Label lbSpeed;
        private System.Windows.Forms.Label lbDes2;
    }
}

